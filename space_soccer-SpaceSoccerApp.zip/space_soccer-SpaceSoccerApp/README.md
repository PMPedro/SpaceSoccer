# space_soccer

This repository refers to the PBL (Project Based Learning) of students in the 2nd Period of the Higher Technical Course for Mobile
Applications.

The Project consists in create a Football Tournament Management application, in the Training category, for Android.

The application is being developed in Android Studio using the Kotlin language, SQL Server for the Database and the Figma program for the design.

The students responsible for the Project are:

Nuno Fernandes --> NunoFighT8

Pedro Martins --> PedroBBC

Yuri Machado --> macyuri94

